## Project Title:

KelvinPeterson_Comp325_Project2

## Files and Use:

preprocessing.py - This is the code used to turn all the csv data into the table so that it can be used in the database.It also has a built in check to make sure the data is added correctly

data_analysis.py - This is the code is used to analyze the data stored in the database. It contains functions for performing various analyses, such as generating bar charts, creating global maps, and summarizing insights. It then executes the appropriate analysis based on the user's selection.

Steel.csv - Raw Data for Steel Table

Solar.csv - Raw Data for Solar Table

Geothermal.csv - Data for Geothermal Table

Energy.db - The database that will store each csv file information in a table
 
README - This current text file explain the role of each file 



### Dependencies:

Before installing and running the program, ensure you have a compatible operating system like Windows, macOS, or Linux. 
You'll also need a Python compiler. You will also need to go to command prompt and install pandas, tkinter and folium if you haven't already before as they are needed libraries to run the code.


### Executing program
There are 3 different results when this program is run. Once the gui pops up the user has the option to select either table steel, solar or geothermal. Once that is done the user can then pick either Bar chart, global map, or Insights summary. Bar Chart will show a bar chart of the total number of active facilities per region depending on what table is selected. Global Map will creaate a pop up asking you if it can open up google chrome or another installed app and what it will do is plot a dot marker on a world map for every
(latitude,longitude) coordinate in the dataset, with blue for steel, orange for solar, and red for geothermal. Insight Summary will print the answer to 5 questions in the console based on what table picked. The questions can be found in the comments above the code used to solve each question in the data_analysis.py file (Under, def print_steel_insights_summary():, def print_solar_insights_summary():, and def print_geothermal_insights_summary():




## Help

If the program fails to read any of the data, ensure that the database contains the data from each csv file, preprocessing may have to be ran uncommented and re-ran in order to do so. Also the Solar map takes a bit to load sense there is so much data, you might have to give it a bit of time to load or just run the program again, but usually patientce works best.


## Author

Kelvin Peterson

## Version History


3/25-3/27: Read intial hand out and made a plan on what to do

3/30-4/1: Converted the excel files to csv-utf8 files and finished the preprocessing.py code.

4/2-4/8: Strictally worked on being able to get the map work, read multiple website on maps to install and had a couple not work and also played around with the dimension of the gui to make sure the apperance what looking at least decent. A lot of bugs and errors occured during this time as well as improper print outs when tested

4/9: Test the code and fixed bug where printing out the Insight Summaries it would only print out the first sentence when ran the first time and then would print out all the answers

4/10: Finished writing up the read me and did final check of code for errors.



