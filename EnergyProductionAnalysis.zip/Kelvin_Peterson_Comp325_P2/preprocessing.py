import sqlite3
import csv
import logging
from typing import Dict, Any, Tuple, Optional

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Constants
DATABASE_PATH = 'Energy.db'
CSV_PATHS = {
    'steel': 'steel.csv',
    'solar': 'solar.csv',
    'geothermal': 'geothermal.csv'
}

class DatabaseManager:
    """Handles database operations for energy data."""
    
    def __init__(self, db_path: str = DATABASE_PATH):
        self.db_path = db_path
        self.connection = None
        try:
            self.connection = sqlite3.connect(self.db_path)
            self._create_tables()
            logger.info("Database connection established and tables verified")
        except sqlite3.Error as e:
            logger.error(f"Database connection failed: {e}")
            raise

    def __del__(self):
        if self.connection:
            self.connection.close()
            logger.info("Database connection closed")

    def _create_tables(self) -> bool:
        """Create database tables if they don't exist."""
        try:
            cursor = self.connection.cursor()
            
            # Steel table
            cursor.execute('''CREATE TABLE IF NOT EXISTS steel (
                            id INTEGER PRIMARY KEY,
                            plant_id TEXT,
                            plant_name TEXT,
                            owner TEXT,
                            country TEXT,
                            region TEXT,
                            latitude REAL,
                            longitude REAL,
                            status TEXT,
                            crude_steel_capacity_ttpa INTEGER
                            )''')
            
            # Solar table
            cursor.execute('''CREATE TABLE IF NOT EXISTS solar (
                            id INTEGER PRIMARY KEY,
                            country TEXT,
                            capacity_MW INTEGER,
                            technology_type TEXT,
                            status TEXT,
                            latitude REAL,
                            longitude REAL,
                            region TEXT
                            )''')
            
            # Geothermal table
            cursor.execute('''CREATE TABLE IF NOT EXISTS geothermal (
                            id INTEGER PRIMARY KEY,
                            country TEXT,
                            project_capacity_MW INTEGER,
                            type TEXT,
                            status TEXT,
                            latitude REAL,
                            longitude REAL,
                            region TEXT
                            )''')
            
            self.connection.commit()
            logger.info("Database tables created/verified successfully")
            return True
            
        except sqlite3.Error as e:
            logger.error(f"Error creating tables: {e}")
            self.connection.rollback()
            return False

    def _is_table_empty(self, table_name: str) -> Tuple[bool, Optional[int]]:
        """Check if table is empty and return row count if not empty."""
        try:
            cursor = self.connection.cursor()
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            count = cursor.fetchone()[0]
            return (count == 0, count)
        except sqlite3.Error as e:
            logger.error(f"Error checking table {table_name}: {e}")
            return (False, None)

    def import_csv_data(self, table_name: str, file_path: str) -> bool:
        """
        Import data from CSV to database table.
        
        Args:
            table_name: Name of target table
            file_path: Path to CSV file
            
        Returns:
            bool: True if operation succeeded (including when skipped due to existing data)
                  False if operation failed
        """
        try:
            # Check if table is empty
            is_empty, count = self._is_table_empty(table_name)
            if not is_empty:
                logger.info(f"Table {table_name} already contains {count} rows. Skipping import.")
                return True
            
            # Read CSV data
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    reader = csv.DictReader(f)
                    rows = [row for row in reader if any(row.values())]
                    
                    if not rows:
                        logger.warning(f"No valid data found in {file_path}")
                        return True
            except (IOError, csv.Error) as e:
                logger.error(f"Error reading CSV file {file_path}: {e}")
                return False
            
            # Insert data
            cursor = self.connection.cursor()
            rows_inserted = 0
            
            for row in rows:
                try:
                    columns = ', '.join(row.keys())
                    placeholders = ', '.join(['?'] * len(row))
                    query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
                    cursor.execute(query, tuple(row.values()))
                    rows_inserted += 1
                except sqlite3.Error as e:
                    logger.warning(f"Error inserting row {rows_inserted + 1}: {e}. Skipping row.")
                    
            
            self.connection.commit()
            logger.info(f"Successfully inserted {rows_inserted} rows into {table_name}")
            return True
            
        except Exception as e:
            logger.error(f"Error importing CSV data to {table_name}: {e}")
            if self.connection:
                self.connection.rollback()
            return False

def main() -> bool:
    """Main data preprocessing function.
    
    Returns:
        bool: True if all operations succeeded, False if any failed
    """
    overall_success = True
    db_manager = None
    
    try:
        db_manager = DatabaseManager()
        
        # Import data from all CSVs
        for table_name, file_path in CSV_PATHS.items():
            success = db_manager.import_csv_data(table_name, file_path)
            if not success:
                overall_success = False
                logger.error(f"Failed to import data for {table_name}")
        
        return overall_success
        
    except Exception as e:
        logger.error(f"Data preprocessing failed: {e}")
        return False
    finally:
        if db_manager:
            del db_manager  # Ensures proper cleanup

if __name__ == "__main__":
    success = main()
    if not success:
        logger.error("Data preprocessing completed with errors")
        exit(1)
    logger.info("Data preprocessing completed successfully")