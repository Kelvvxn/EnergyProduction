import sqlite3
import pandas as pd
import folium
from tkinter import Tk, Label, Button, OptionMenu, StringVar, Canvas, messagebox
from typing import List, Tuple, Optional, Any


def perform_analysis(dataset: str, analysis: str, canvas: Canvas) -> None:
    """
    Perform analysis based on user's selection and display results on canvas.
    
    Args:
        dataset: The dataset to analyze ('Steel', 'Solar', or 'Geothermal')
        analysis: The type of analysis to perform ('Bar Chart', 'Global Map', or 'Insights Summary')
        canvas: The Tkinter Canvas widget where results will be displayed
        
    """
    try:
        connection = sqlite3.connect('Energy.db')
        cursor = connection.cursor()
        
        if analysis == "Bar Chart":  
            if dataset == "Steel":
                cursor.execute("SELECT region, COUNT(*) FROM steel WHERE status = 'operating' GROUP BY region")
                rows = cursor.fetchall()
                regions, counts = zip(*rows) if rows else ([], [])
                draw_bar_chart(canvas, regions, counts, "Total Number of Active Steel Facilities per Region")
            elif dataset == "Solar":
                cursor.execute("SELECT region, COUNT(*) FROM solar WHERE status = 'operating' GROUP BY region")
                rows = cursor.fetchall()
                regions, counts = zip(*rows) if rows else ([], [])
                draw_bar_chart(canvas, regions, counts, "Total Number of Active Solar Facilities per Region")
            elif dataset == "Geothermal":
                cursor.execute("SELECT region, COUNT(*) FROM geothermal WHERE status = 'operating' GROUP BY region")
                rows = cursor.fetchall()
                regions, counts = zip(*rows) if rows else ([], [])
                draw_bar_chart(canvas, regions, counts, "Total Number of Active Geothermal Facilities per Region")
                
        elif analysis == "Global Map":  
            if dataset in ["Steel", "Solar", "Geothermal"]:
                if dataset == "Steel":
                    columns = "latitude, longitude, country, plant_name, status"
                elif dataset == "Solar":
                    columns = "latitude, longitude, country, owner, status"
                elif dataset == "Geothermal":
                    columns = "latitude, longitude, country, project_name, status"

                cursor.execute(f"SELECT {columns} FROM {dataset.lower()} WHERE status = 'operating'")
                data = cursor.fetchall()
                if not data:
                    messagebox.showinfo("No Data", "No data available for selected dataset.")
                else:
                    df = pd.DataFrame(data, columns=columns.split(", "))
                    create_global_map(df, dataset)
            else:
                messagebox.showinfo("Invalid Dataset", "Please select a valid dataset.")
        
        elif analysis == "Insights Summary":
            if dataset == "Steel":
                summary = print_steel_insights_summary()
            elif dataset == "Solar":
                summary = print_solar_insights_summary()
            elif dataset == "Geothermal":
                summary = print_geothermal_insights_summary()
            display_text_on_canvas(canvas, summary)

    except sqlite3.Error as e:
        messagebox.showerror("Database Error", f"Database operation failed: {str(e)}")
    except Exception as e:
        messagebox.showerror("Error", f"An unexpected error occurred: {str(e)}")
    finally:
        if 'connection' in locals():
            connection.close()


def draw_bar_chart(canvas: Canvas, labels: List[str], values: List[int], title: str) -> None:
    """
    Draw a bar chart on the provided canvas.
    
    Args:
        canvas: The Canvas widget to draw on
        labels: List of labels for each bar
        values: List of values for each bar
        title: Title to display above the chart

    """
    try:
        canvas.delete("all")
        
        chart_width = 700 
        chart_height = 400
        margin = 50
        bar_spacing = 50
        max_bar_width = 100
        
        bar_width = min(max_bar_width, 
                       (chart_width - (len(labels) + 1) * bar_spacing) / len(labels))
        
        max_value = max(values) if values else 1
        scale = (chart_height - 100) / max_value
        
        canvas.create_text(chart_width / 2 + margin, 20, 
                          text=title, font=("Arial", 14, "bold"))
        
        for i, (label, value) in enumerate(zip(labels, values)):
            x0 = margin + i * (bar_width + bar_spacing)
            y0 = chart_height - value * scale + margin
            x1 = x0 + bar_width
            y1 = chart_height + margin
            
            canvas.create_rectangle(x0, y0, x1, y1, fill="skyblue")
            canvas.create_text((x0 + x1) / 2, y0 - 15, 
                             text=str(value), font=("Arial", 10))
            
            font_size = 9 if len(label) <= 12 else 8 if len(label) <= 15 else 7
            canvas.create_text((x0 + x1) / 2, y1 + 20, 
                             text=label, font=("Arial", font_size))
        
        canvas.create_line(margin, margin, margin, chart_height + margin, width=2)
        canvas.create_line(margin, chart_height + margin, 
                          chart_width + margin, chart_height + margin, width=2)
    
    except Exception as e:
        messagebox.showerror("Chart Error", f"Failed to draw bar chart: {str(e)}")


def create_global_map(df: pd.DataFrame, dataset: str) -> None:
    """
    Create and display an interactive global map showing facility locations.
    
    Args:
        df: DataFrame containing facility data with columns:
            - latitude: float, latitude coordinate
            - longitude: float, longitude coordinate
            - country: str, country name
            - name_field: str, facility name (plant_name/owner/project_name)
            - status: str, operational status
        dataset: The type of facility ('Steel', 'Solar', or 'Geothermal')

    """

    try:
        from folium.plugins import MarkerCluster
        
        # Create base map with better tiles
        m = folium.Map(
            location=[20, 0],
            zoom_start=2,
            tiles='cartodbpositron',  # Clean light theme
            control_scale=True
        )
        
        # Add marker cluster for performance
        marker_cluster = MarkerCluster().add_to(m)
        
        # Determine name field based on dataset
        name_field = 'plant_name' if dataset == 'Steel' else 'owner' if dataset == 'Solar' else 'project_name'
        
        # Create color mapping and icons
        style_config = {
            'Steel': {'color': 'blue', 'icon': 'industry', 'filename': 'steel_global_map.html'},
            'Solar': {'color': 'orange', 'icon': 'sun', 'filename': 'solar_global_map.html'},
            'Geothermal': {'color': 'green', 'icon': 'bolt', 'filename': 'geothermal_global_map.html'}
        }
        style = style_config.get(dataset, {'color': 'red', 'icon': 'info', 'filename': 'global_map.html'})
        
        # Add each facility to the map
        for _, row in df.iterrows():
            # Create beautiful HTML popup
            popup_content = f"""
            <div style="font-family: Arial; width: 250px;">
                <h4 style="color: {style['color']}; margin: 5px 0;">
                    {row[name_field]}
                </h4>
                <hr style="margin: 5px 0;">
                <p><b>Type:</b> {dataset} Facility</p>
                <p><b>Status:</b> <span style="color: {'green' if str(row['status']).lower() == 'operating' else 'orange'}">
                    {str(row['status']).title()}
                </span></p>
                <p><b>Country:</b> {row['country']}</p>
                <p><b>Location:</b><br>
                {row['latitude']:.4f}, {row['longitude']:.4f}</p>
            </div>
            """
            
            # Create marker with custom icon
            folium.Marker(
                location=[row['latitude'], row['longitude']],
                popup=folium.Popup(popup_content, max_width=300),
                icon=folium.Icon(
                    color=style['color'],
                    icon=style['icon'],
                    prefix='fa'
                )
            ).add_to(marker_cluster)
        
        # Add map title
        title_html = f"""
            <h3 style="
                position: fixed;
                top: 10px;
                left: 50%;
                transform: translateX(-50%);
                z-index: 1000;
                background: white;
                padding: 5px 15px;
                border-radius: 5px;
                box-shadow: 0 0 5px rgba(0,0,0,0.2);
                font-family: Arial;
                font-size: 16px;
            ">
                {dataset} Facilities Worldwide
            </h3>
        """
        m.get_root().html.add_child(folium.Element(title_html))
        
        # Save with dataset-specific filename
        map_filename = style['filename']
        m.save(map_filename)
        
        # Open in browser
        import webbrowser
        webbrowser.open(map_filename)
        
    except Exception as e:
        messagebox.showerror("Map Error", f"Failed to create global map: {str(e)}")


def print_steel_insights_summary() -> str:
    """
    Generate and return insights summary for steel facilities.
    
    Returns:
        str: A multi-line string containing the insights summary

    """
    try:
        connection = sqlite3.connect('Energy.db')
        cursor = connection.cursor()
        summary = "Steel Insight Summary:\n"

        cursor.execute("SELECT COUNT(*) FROM steel WHERE status IN ('announced', 'construction')")
        announced_construction_count = cursor.fetchone()[0]
        summary += f"1. Number of steel plants in the 'announced' or 'construction' phase globally: {announced_construction_count}\n"

        cursor.execute("SELECT COUNT(*) FROM steel WHERE status = 'operating'")
        operating_count = cursor.fetchone()[0]
        summary += f"2. Number of steel plants currently in their 'operating' phase globally: {operating_count}\n"

        cursor.execute("SELECT COUNT(*) FROM steel WHERE status = 'operating' AND country = 'United States'")
        operating_us_count = cursor.fetchone()[0]
        summary += f"3. Number of steel plants currently in their 'operating' phase in the United States: {operating_us_count}\n"

        cursor.execute("SELECT country, COUNT(*) FROM steel WHERE status = 'operating' GROUP BY country ORDER BY COUNT(*) DESC LIMIT 1")
        country, count = cursor.fetchone()
        summary += f"4. Country with the highest number of active steel plants: {country} ({count} plants)\n"

        cursor.execute("SELECT plant_name, MAX(crude_steel_capacity_ttpa) FROM steel")
        plant_name, max_capacity = cursor.fetchone()
        summary += f"5. Steel plant with the highest production capacity: {plant_name} ({max_capacity} t/tpa)\n"
        
        return summary

    except sqlite3.Error as e:
        return f"Error generating steel insights: {str(e)}"
    finally:
        if 'connection' in locals():
            connection.close()


def print_solar_insights_summary() -> str:
    """
    Generate and return insights summary for solar facilities.
    
    Returns:
        str: A multi-line string containing the insights summary

    """
    try:
        connection = sqlite3.connect('Energy.db')
        cursor = connection.cursor()
        summary = "Solar Insight Summary:\n"

        cursor.execute("SELECT COUNT(*) FROM solar WHERE status IN ('announced', 'pre-construction', 'construction')")
        total_solar_plants_in_construction = cursor.fetchone()[0]
        summary += f"1. Number of solar energy plants in construction phase globally: {total_solar_plants_in_construction}\n"

        cursor.execute("SELECT COUNT(*) FROM solar WHERE status = 'operating'")
        total_solar_plants_operating = cursor.fetchone()[0]
        summary += f"2. Number of solar energy plants currently in operating phase globally: {total_solar_plants_operating}\n"

        cursor.execute("SELECT COUNT(*) FROM solar WHERE status = 'operating' AND country = 'United States'")
        total_solar_plants_operating_us = cursor.fetchone()[0]
        summary += f"3. Number of solar energy plants currently in operating phase in the United States: {total_solar_plants_operating_us}\n"

        cursor.execute("SELECT country, MAX(capacity_MW) FROM solar")
        country_with_max_capacity, max_capacity = cursor.fetchone()
        summary += f"4. Country with the highest solar energy production capacity: {country_with_max_capacity} (Capacity: {max_capacity} MW)\n"

        cursor.execute("SELECT technology_type, COUNT(*) FROM solar GROUP BY technology_type ORDER BY COUNT(*) DESC LIMIT 1")
        most_common_technology, count = cursor.fetchone()
        summary += f"5. Most common technology type of solar energy plant globally: {most_common_technology} (Count: {count})\n"

        return summary

    except sqlite3.Error as e:
        return f"Error generating solar insights: {str(e)}"
    finally:
        if 'connection' in locals():
            connection.close()


def print_geothermal_insights_summary() -> str:
    """
    Generate and return insights summary for geothermal facilities.
    
    Returns:
        str: A multi-line string containing the insights summary
    
    """
    try:
        connection = sqlite3.connect('Energy.db')
        cursor = connection.cursor()    
        summary = "Geothermal Insight Summary:\n"
        
        cursor.execute("SELECT COUNT(*) FROM geothermal WHERE status IN ('announcement', 'pre-construction', 'construction')")
        total_geothermal_plants_in_construction = cursor.fetchone()[0]
        summary += f"1. Number of geothermal energy plants in construction phase globally: {total_geothermal_plants_in_construction}\n"

        cursor.execute("SELECT COUNT(*) FROM geothermal WHERE status = 'operating'")
        total_geothermal_plants_operating = cursor.fetchone()[0]
        summary += f"2. Number of geothermal energy plants currently in operating phase globally: {total_geothermal_plants_operating}\n"

        cursor.execute("SELECT COUNT(*) FROM geothermal WHERE status = 'operating' AND country = 'United States'")
        total_geothermal_plants_operating_us = cursor.fetchone()[0]
        summary += f"3. Number of geothermal energy plants currently in operating phase in the United States: {total_geothermal_plants_operating_us}\n"

        cursor.execute("SELECT country, MAX(project_capacity_MW) FROM geothermal")
        country_with_max_capacity, max_capacity = cursor.fetchone()
        summary += f"4. Country with the highest geothermal energy production capacity: {country_with_max_capacity} (Capacity: {max_capacity} MW)\n"

        cursor.execute("SELECT type, COUNT(*) FROM geothermal GROUP BY type ORDER BY COUNT(*) DESC LIMIT 1")
        most_common_type, count = cursor.fetchone()
        summary += f"5. Most common type of geothermal plant globally: {most_common_type} (Count: {count})\n"

        return summary

    except sqlite3.Error as e:
        return f"Error generating geothermal insights: {str(e)}"
    finally:
        if 'connection' in locals():
            connection.close()


def display_text_on_canvas(canvas: Canvas, text: str) -> None:
    """
    Display text on the canvas.
    
    Args:
        canvas: The Tkinter Canvas widget
        text: The text to display
    """
    try:
        canvas.delete("all")
        text_widget = canvas.create_text(10, 10, anchor="nw", text=text, font=("Arial", 10), width=780)
        canvas.itemconfig(text_widget, width=780)
    except Exception as e:
        messagebox.showerror("Display Error", f"Failed to display text: {str(e)}")


def main() -> None:
    """
    Initialize and run the main application window for energy analysis.
    
    Creates a Tkinter GUI with dataset selection, analysis options, and display canvas.
    """
    try:
        root = Tk()
        root.title("Energy Analysis")
        root.geometry("900x700")

        dataset_label = Label(root, text="Select dataset:")
        dataset_label.pack()
        dataset_var = StringVar(root)
        dataset_var.set("Select Dataset")
        dataset_options = ["Steel", "Solar", "Geothermal"]
        dataset_menu = OptionMenu(root, dataset_var, *dataset_options)
        dataset_menu.pack()

        analysis_label = Label(root, text="Select analysis:")
        analysis_label.pack()
        analysis_var = StringVar(root)
        analysis_var.set("Select Analysis")
        analysis_options = ["Bar Chart", "Global Map", "Insights Summary"]
        analysis_menu = OptionMenu(root, analysis_var, *analysis_options)
        analysis_menu.pack()

        canvas = Canvas(root, width=880, height=550)
        canvas.pack()

        def perform():
            dataset = dataset_var.get()
            analysis = analysis_var.get()
            perform_analysis(dataset, analysis, canvas)

        perform_button = Button(root, text="Perform Analysis", command=perform)
        perform_button.pack()

        root.mainloop()
    except Exception as e:
        messagebox.showerror("Application Error", f"Failed to start application: {str(e)}")


if __name__ == "__main__":
    main()